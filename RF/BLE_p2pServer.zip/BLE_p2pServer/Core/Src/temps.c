/*
 * temps.c
 *
 *  Created on: May 26, 2025
 *      Author: axelt
 */

#import "temps.h"

static long temps = 0;
static long start = 0;

void Chrono_Start(){
	start = HAL_GetTick();
}

long Chrono_GetTime(){
	return HAL_GetTick()-start;
}
