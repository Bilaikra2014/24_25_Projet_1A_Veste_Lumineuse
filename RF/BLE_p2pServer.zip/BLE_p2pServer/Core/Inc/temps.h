/*
 * temps.h
 *
 *  Created on: May 26, 2025
 *      Author: axelt
 */

#ifndef INC_TEMPS_H_
#define INC_TEMPS_H_
#include "stm32wbxx_hal.h"

void Chrono_Start();

long Chrono_GetTime();

#endif /* INC_TEMPS_H_ */
