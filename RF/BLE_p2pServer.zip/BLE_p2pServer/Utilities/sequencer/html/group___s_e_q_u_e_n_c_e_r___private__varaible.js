var group___s_e_q_u_e_n_c_e_r___private__varaible =
[
    [ "CurrentTaskIdx", "group___s_e_q_u_e_n_c_e_r___private__varaible.html#ga2d00e58496abe08f37dfaa2679226c35", null ],
    [ "EvtSet", "group___s_e_q_u_e_n_c_e_r___private__varaible.html#ga4c0c4cdb1e59756fac982daba7f66e8c", null ],
    [ "EvtWaited", "group___s_e_q_u_e_n_c_e_r___private__varaible.html#ga2993ab71529fc7f716b41b74c1475889", null ],
    [ "SuperMask", "group___s_e_q_u_e_n_c_e_r___private__varaible.html#ga0c890a69236d5f7438c51df3cf20c480", null ],
    [ "TaskCb", "group___s_e_q_u_e_n_c_e_r___private__varaible.html#ga893dc0e5ab501c52067b7eda416249aa", null ],
    [ "TaskMask", "group___s_e_q_u_e_n_c_e_r___private__varaible.html#ga5ac59b09d15935337ee4a154db1cde25", null ],
    [ "TaskPrio", "group___s_e_q_u_e_n_c_e_r___private__varaible.html#ga1a1b2fb52456411a929b68a015a66635", null ],
    [ "TaskSet", "group___s_e_q_u_e_n_c_e_r___private__varaible.html#gacf3f1ab2184d36d2cb57326539e3563b", null ]
];